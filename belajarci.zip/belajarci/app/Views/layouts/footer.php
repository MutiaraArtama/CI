<footer class="footer ">
    <div class="container ">
        <span class="text-muted "> Mutiara Azzahrani Artama. 4 ITE 2.</span>
    </div>
</footer>